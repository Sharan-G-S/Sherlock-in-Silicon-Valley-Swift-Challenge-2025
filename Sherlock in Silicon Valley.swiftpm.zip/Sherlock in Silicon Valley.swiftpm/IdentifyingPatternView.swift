import SwiftUI

struct IdentifyingPatternView: View {
    @State private var userInput = ""
    @State private var currentLevel = 1
    @State private var isCompleted = false
    @State private var feedbackMessage = ""
    @State private var feedbackColor = Color.clear
    @State private var showFeedback = false
    @State private var navigateToHome = false
    
    // Predefined patterns with answers
    let levels = [
        (pattern: "1, 1, 2, 3, 5, 8, ?", answer: "13"),   // Fibonacci sequence
        (pattern: "2, 4, 8, 16, ?", answer: "32"),        // Powers of 2
        (pattern: "3, 9, 27, 81, ?", answer: "243")       // Powers of 3
    ]

    var body: some View {
        ZStack {
            // 🌈 Background Gradient
            LinearGradient(gradient: Gradient(colors: [Color.black, Color.purple, Color.blue]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 30) {
                if isCompleted {
                    // 🎉 Congratulations Screen 🎉
                    Text("🎉 Congratulations! ")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.green)
                        .padding()
                        .shadow(color: .green, radius: 5, x: 0, y: 3)
                    
                    Text("You have completed the Pattern Identification Game!")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)
                        .padding()

                    // 🏠 Navigation to HomeView
                    NavigationLink(destination: HomeView(), isActive: $navigateToHome) {
                        Button(action: {
                            navigateToHome = true
                        }) {
                            Text("Go to Home Page")
                                .font(.title2)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .shadow(color: .blue, radius: 5, x: 0, y: 3)
                        }
                    }
                } else {
                    // 🧠 Game Levels 🧠
                    Text("Level \(currentLevel)")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.white)
                        .padding()

                    Text("Identify the next number in the sequence:")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)

                    // 📊 Pattern Question Display
                    Text(levels[currentLevel - 1].pattern)
                        .font(.system(size: 60, weight: .bold, design: .rounded))
                        .padding()
                        .background(
                            LinearGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]), startPoint: .leading, endPoint: .trailing)
                        )
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .shadow(color: .orange, radius: 8, x: 0, y: 4)

                    // ✍️ User Input Field
                    TextField("Enter the next number", text: $userInput)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        .font(.system(size: 24))
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(10)

                    // ✅ Submit Button
                    Button(action: checkAnswer) {
                        Text("Submit")
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(15)
                            .shadow(color: .green, radius: 5, x: 0, y: 3)
                    }
                    .padding(.horizontal, 40)

                    // 🎯 Feedback Message
                    if showFeedback {
                        Text(feedbackMessage)
                            .font(.title2)
                            .bold()
                            .foregroundColor(feedbackColor)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(color: feedbackColor, radius: 5, x: 0, y: 3)
                            .transition(.scale)
                    }
                }
            }
            .padding()
        }
    }

    // 🧮 Answer Validation Logic
    func checkAnswer() {
        let correctAnswer = levels[currentLevel - 1].answer.lowercased()
        if userInput.lowercased() == correctAnswer {
            feedbackMessage = "Correct! ✅"
            feedbackColor = .green
            showFeedback = true

            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                if currentLevel < levels.count {
                    showFeedback = false
                    currentLevel += 1
                    userInput = ""
                } else {
                    isCompleted = true
                    showFeedback = false
                }
            }
        } else {
            feedbackMessage = "Wrong answer! Try again. ❌"
            feedbackColor = .red
            showFeedback = true
        }
    }
}

// 🧪 Mock Preview
struct IdentifyingPatternView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            IdentifyingPatternView()
        }
    }
}
