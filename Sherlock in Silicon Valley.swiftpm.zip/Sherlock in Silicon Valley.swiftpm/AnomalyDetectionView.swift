import SwiftUI

struct AnomalyDetectionView: View {
    @State private var userInput = ""
    @State private var currentLevel = 1
    @State private var isCompleted = false
    @State private var feedbackMessage = ""
    @State private var feedbackColor = Color.clear
    @State private var showFeedback = false
    @State private var navigateToHome = false
    
    // Predefined anomaly detection levels
    let levels = [
        (question: "What is the anomaly in this sequence? 2, 4, 8, 16, 31, 64", answer: "31"), // Level 1
        (question: "Identify the anomaly: Sun, Mon, Tue, Wed, Red, Fri, Sat", answer: "Red"),   // Level 2
        (question: "Find the anomaly: 5, 10, 20, 40, 85, 160", answer: "85")                   // Level 3
    ]

    var body: some View {
        ZStack {
            // 🌈 Background Gradient
            LinearGradient(gradient: Gradient(colors: [Color.black, Color.purple, Color.blue]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                if isCompleted {
                    // 🎉 Congratulations Screen
                    Text("🎉 Congratulations! ")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.green)
                        .padding()
                        .shadow(color: .green, radius: 5, x: 0, y: 3)
                    
                    Text("You have successfully completed the Anomaly Detection Game!")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)
                        .padding()

                    // 🏠 Navigation to HomeView
                    NavigationLink(destination: HomeView(), isActive: $navigateToHome) {
                        Button(action: {
                            navigateToHome = true
                        }) {
                            Text("Go to Home Page")
                                .font(.title2)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .shadow(color: .blue, radius: 5, x: 0, y: 3)
                        }
                    }
                } else {
                    // 🧠 Game Levels
                    Text("Level \(currentLevel)")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.white)
                        .padding()
                    
                    Text("What is the anomaly in the question below?")
                        .font(.title2)
                        .foregroundColor(.white)
                    
                    // 📊 Anomaly Question Display
                    Text(levels[currentLevel - 1].question)
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                        .padding()
                        .background(
                            LinearGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]), startPoint: .leading, endPoint: .trailing)
                        )
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .shadow(color: .orange, radius: 5, x: 0, y: 3)

                    // ✍️ User Input Field
                    TextField("Enter your answer", text: $userInput)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        .font(.title2)
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(10)

                    // ✅ Submit Button
                    Button(action: checkAnswer) {
                        Text("Submit")
                            .font(.title2)
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(color: .green, radius: 5, x: 0, y: 3)
                    }
                    
                    // 🎯 Feedback Message
                    if showFeedback {
                        Text(feedbackMessage)
                            .font(.title2)
                            .bold()
                            .foregroundColor(feedbackColor)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(color: feedbackColor, radius: 5, x: 0, y: 3)
                            .transition(.scale)
                    }
                }
            }
            .padding()
        }
    }

    // 🧮 Answer Validation Logic
    func checkAnswer() {
        let correctAnswer = levels[currentLevel - 1].answer.lowercased()
        if userInput.lowercased() == correctAnswer {
            feedbackMessage = "Correct! ✅"
            feedbackColor = .green
            showFeedback = true
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                if currentLevel < levels.count {
                    showFeedback = false
                    currentLevel += 1
                    userInput = ""
                } else {
                    isCompleted = true
                    showFeedback = false
                }
            }
        } else {
            feedbackMessage = "Wrong answer! Try again. ❌"
            feedbackColor = .red
            showFeedback = true
        }
    }
}

// 🧪 Mock Preview
struct AnomalyDetectionView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            AnomalyDetectionView()
        }
    }
}
