import SwiftUI

struct ContentView: View {
    @EnvironmentObject var navigation: NavigationManager
    
    var body: some View {
        NavigationStack {
            switch navigation.currentView {
            case "StartView":
                StartView()
            case "HomeView":
                HomeView()
            case "IdentifyingPatternView":
                IdentifyingPatternView()
            default:
                HomeView()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(NavigationManager()) // Ensure environment object is set
    }
}
