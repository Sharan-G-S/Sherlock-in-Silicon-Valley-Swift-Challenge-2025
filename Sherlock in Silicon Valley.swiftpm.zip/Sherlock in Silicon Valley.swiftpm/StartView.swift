import SwiftUI

struct StartView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.purple, Color.blue, Color.pink]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
                RoundedRectangle(cornerRadius: 20)
                    .strokeBorder(
                        LinearGradient(colors: [Color.yellow, Color.orange], startPoint: .topLeading, endPoint: .bottomTrailing),
                        lineWidth: 8
                    )
                    .padding(10)
                
                VStack(spacing: 28) {
                    Spacer(minLength: 20)
                    
                    Text("AI is the key to unlocking cybersecurity mysteries.")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black.opacity(0.7))
                        .cornerRadius(10)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                        .fixedSize(horizontal: false, vertical: true)
                    
                    Text("🍎🕵️‍♂️🔍🤖")
                        .font(.largeTitle)
                    
                    VStack(spacing: 10) {
                        Text("Sherlock")
                            .font(.system(size: 50, weight: .bold))
                            .foregroundStyle(
                                LinearGradient(colors: [Color.yellow, Color.orange], startPoint: .top, endPoint: .bottom)
                            )
                            .shadow(color: .black, radius: 5, x: 2, y: 2)
                        
                        Text("in")
                            .font(.system(size: 30, weight: .bold))
                            .foregroundColor(.white)
                            .shadow(color: .black, radius: 2, x: 1, y: 1)
                        
                        Text("Silicon Valley")
                            .font(.system(size: 50, weight: .bold))
                            .foregroundStyle(
                                LinearGradient(colors: [Color.yellow, Color.orange], startPoint: .top, endPoint: .bottom)
                            )
                            .shadow(color: .black, radius: 5, x: 2, y: 2)
                    }
                    .padding(.vertical, 30)
                    
                    Text("Are you ready to dive into the world of AI & Cybersecurity?")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black.opacity(0.7))
                        .cornerRadius(10)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                        .fixedSize(horizontal: false, vertical: true)
                    
                    NavigationLink(destination: HomeView()) {
                        Text("Start Investigation")
                            .font(.title2)
                            .fontWeight(.bold)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(15)
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.yellow, lineWidth: 5)
                            )
                            .shadow(color: .yellow, radius: 10, x: 0, y: 5)
                    }
                    .padding(.horizontal, 40)
                    .padding(.bottom, 50)
                    
                    Spacer(minLength: 20)
                }
                .padding()
            }
        }
    }
}

struct StartView_Previews: PreviewProvider {
    static var previews: some View {
        StartView()
    }
}
