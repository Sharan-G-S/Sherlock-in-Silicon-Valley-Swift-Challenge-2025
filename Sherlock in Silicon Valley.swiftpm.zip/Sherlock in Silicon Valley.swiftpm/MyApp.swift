import SwiftUI

@main
struct SherlockInSiliconValleyApp: App {
    @StateObject var navigation = NavigationManager()
    
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                switch navigation.currentView {
                case "HomeView":
                    HomeView()
                        .environmentObject(navigation)
                
                case "CipherTextSolverView":
                    CipherTextSolverView()
                        .environmentObject(navigation)
                
                case "WordSearchView":
                    WordSearchView()
                        .environmentObject(navigation)
                
                case "IdentifyingPatternView":
                    IdentifyingPatternView()
                        .environmentObject(navigation)
                
                case "AnomalyDetectionView":
                    AnomalyDetectionView()
                        .environmentObject(navigation)
                
                default:
                    StartView()
                        .environmentObject(navigation)
                }
            }
            .animation(.easeInOut, value: navigation.currentView)
        }
    }
}
