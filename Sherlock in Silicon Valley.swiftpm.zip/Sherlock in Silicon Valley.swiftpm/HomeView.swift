import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                // 🌌 Premium Double Gradient Neon Background
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.blue.opacity(0.6)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                // ✨ Neon Glow Overlay
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple, Color.clear, Color.blue]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .opacity(0.3)
                .blur(radius: 50)
                .ignoresSafeArea()
                
                VStack(spacing: 50) {
                    Text("Select Your Investigation")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .foregroundColor(.white)
                        .shadow(color: .purple, radius: 10, x: 2, y: 2)
                    
                    // 🕵️‍♂️ Sherlock in Silicon Valley Bold Quote
                    Text("“Unravel mysteries, decode reality — Welcome to Sherlock in Silicon Valley!”")
                        .font(.title)
                        .fontWeight(.bold) // Bold Font
                        .foregroundColor(.white.opacity(0.9))
                        .padding(.horizontal)
                        .multilineTextAlignment(.center)
                        .shadow(color: .blue, radius: 5, x: 1, y: 1)
                    
                    VStack(spacing: 30) {
                        gradientButton(
                            title: "Cipher Text Solver",
                            gradient: [Color.green, Color.teal],
                            destination: CipherTextSolverView()
                        )
                        
                        gradientButton(
                            title: "Word Search (AI)",
                            gradient: [Color.yellow, Color.orange],
                            destination: WordSearchView()
                        )
                        
                        gradientButton(
                            title: "Identifying Pattern",
                            gradient: [Color.red, Color.pink],
                            destination: IdentifyingPatternView()
                        )
                        
                        gradientButton(
                            title: "Anomalies Detection",
                            gradient: [Color.purple, Color.indigo],
                            destination: AnomalyDetectionView()
                        )
                    }
                    .padding(.horizontal, 40)
                }
            }
        }
    }
    
    // 🎨 Gradient Button with Bold Text and Full Color Fill
    @ViewBuilder
    private func gradientButton<Destination: View>(title: String, gradient: [Color], destination: Destination) -> some View {
        NavigationLink(destination: destination) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .padding()
                .frame(maxWidth: .infinity)
                .background(
                    LinearGradient(colors: gradient, startPoint: .leading, endPoint: .trailing)
                )
                .foregroundColor(.white)
                .cornerRadius(20)
                .shadow(color: .black.opacity(0.2), radius: 8, x: 5, y: 5)
        }
    }
}

// ✅ Preview Code
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
