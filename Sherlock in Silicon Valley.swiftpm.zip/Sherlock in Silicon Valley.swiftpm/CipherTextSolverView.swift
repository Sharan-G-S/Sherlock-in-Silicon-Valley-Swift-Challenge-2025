import SwiftUI

struct CipherTextSolverView: View {
    @State private var userInput = ""
    @State private var currentLevel = 1
    @State private var feedbackMessage = ""
    @State private var feedbackColor = Color.clear
    @State private var showFeedback = false
    @State private var showCompletionPopup = false
    @State private var navigateToHome = false
    
    let levels = [
        (text: "Pyhuzovwly", shift: 11, answer: "Blockchain"),
        (text: "Hafzjizjf", shift: 19, answer: "Algorithms"),
        (text: "Tfbulwbz Extjwz", shift: 7, answer: "Machine Learning"),
        (text: "Plydpplqj", shift: 22, answer: "Programming"),
        (text: "Xuilflfldo Lqwhooljhqfh", shift: 22, answer: "Artificial Intelligence")
    ]
    
    var body: some View {
        ZStack {
            // 🌈 Background Gradient
            LinearGradient(gradient: Gradient(colors: [Color.black, Color.purple, Color.blue]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                Text("Level \(currentLevel)")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.white)
                    .padding()
                
                Text("Decrypt the highlighted text:")
                    .font(.title2)
                    .foregroundColor(.white)
                
                // 🕵️‍♂️ Cipher Text Display
                Text(levels[currentLevel - 1].text)
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .padding()
                    .background(
                        LinearGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]), startPoint: .leading, endPoint: .trailing)
                    )
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .shadow(color: .orange, radius: 5, x: 0, y: 3)
                
                Text("Clue: Shift by \(levels[currentLevel - 1].shift)")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.white)
                    .padding()
                
                // ✍️ User Input Field
                TextField("Enter decrypted text", text: $userInput)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    .font(.title2)
                    .background(Color.white.opacity(0.8))
                    .cornerRadius(10)
                
                // ✅ Submit Button
                Button(action: checkAnswer) {
                    Text("Submit")
                        .font(.title2)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .shadow(color: .green, radius: 5, x: 0, y: 3)
                }
                .padding(.horizontal)
                
                // 🎯 Feedback Message
                if showFeedback {
                    Text(feedbackMessage)
                        .font(.title2)
                        .bold()
                        .foregroundColor(feedbackColor)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(color: feedbackColor, radius: 5, x: 0, y: 3)
                        .transition(.scale)
                        .animation(.easeInOut, value: showFeedback)
                }
            }
            
            // 🏆 Completion Popup
            if showCompletionPopup {
                ZStack {
                    Color.black.opacity(0.6).ignoresSafeArea()
                    
                    VStack(spacing: 20) {
                        HStack {
                            Text("🎉")
                            Text("Congratulations")
                                .font(.largeTitle)
                                .bold()
                                .foregroundColor(.green)
                        }
                        
                        Text("You have completed the Decryption Investigation!")
                            .font(.title2)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.white)
                            .padding()
                        
                        // 🏠 Navigation to HomeView
                        NavigationLink(destination: HomeView(), isActive: $navigateToHome) {
                            Button(action: {
                                navigateToHome = true
                            }) {
                                Text("Go to Home Page")
                                    .font(.title2)
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .shadow(color: .blue, radius: 5, x: 0, y: 3)
                            }
                        }
                        .padding(.horizontal)
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(20)
                    .shadow(radius: 10)
                    .padding(.horizontal, 40)
                }
            }
        }
    }
    
    // 🧮 Answer Validation Logic
    func checkAnswer() {
        let correctAnswer = levels[currentLevel - 1].answer.lowercased()
        if userInput.lowercased() == correctAnswer {
            feedbackMessage = "Correct! ✅"
            feedbackColor = .green
            showFeedback = true
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                if currentLevel < levels.count {
                    currentLevel += 1
                    userInput = ""
                    showFeedback = false
                } else {
                    showCompletionPopup = true
                    showFeedback = false
                }
            }
        } else {
            feedbackMessage = "Wrong answer! Try again. ❌"
            feedbackColor = .red
            showFeedback = true
        }
    }
}

// 🧪 Mock Preview
struct CipherTextSolverView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            CipherTextSolverView()
        }
    }
}
