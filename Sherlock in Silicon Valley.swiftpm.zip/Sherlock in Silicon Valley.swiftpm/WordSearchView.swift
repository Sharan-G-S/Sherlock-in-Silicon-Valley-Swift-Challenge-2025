import SwiftUI

struct WordSearchView: View {
    @State private var currentLevel = 1
    @State private var isCompleted = false
    @State private var feedbackMessage = ""
    @State private var feedbackColor = Color.clear
    @State private var showFeedback = false
    @State private var navigateToHome = false
    
    // Predefined word search questions and answers
    let questions = [
        (question: "What does AI stand for?", options: ["Automatic Information", "Artificial Intelligence", "Advanced Integration", "Adaptive Input"], answer: "Artificial Intelligence"),
        (question: "Which is a type of cybersecurity threat?", options: ["Fishing", "Dishing", "Swishing", "Phishing"], answer: "Phishing"),
        (question: "Which algorithm is used in Machine Learning?", options: ["Cooking Recipes", "Grammar Rules", "Driving Laws", "Linear Regression"], answer: "Linear Regression")
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.black, Color.purple, Color.blue]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                if isCompleted {
                    Text("🎉 Congratulations! ")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.green)
                        .padding()
                        .shadow(color: .green, radius: 5, x: 0, y: 3)
                    
                    Text("You have completed the Word Search Game!")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)
                        .padding()
                    
                    NavigationLink(destination: HomeView(), isActive: $navigateToHome) {
                        Button(action: {
                            navigateToHome = true
                        }) {
                            Text("Go to Home Page")
                                .font(.title2)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .shadow(color: .blue, radius: 5, x: 0, y: 3)
                        }
                    }
                } else {
                    Text("Level \(currentLevel)")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.white)
                        .padding()
                    
                    Text(questions[currentLevel - 1].question)
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)
                        .padding()
                    
                    ForEach(questions[currentLevel - 1].options, id: \.self) { option in
                        Button(action: {
                            checkAnswer(option: option)
                        }) {
                            Text(option)
                                .font(.title2)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(LinearGradient(gradient: Gradient(colors: [Color.orange, Color.pink, Color.blue]), startPoint: .leading, endPoint: .trailing))
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .shadow(color: .pink, radius: 5, x: 0, y: 3)
                        }
                    }
                    
                    if showFeedback {
                        Text(feedbackMessage)
                            .font(.title2)
                            .bold()
                            .foregroundColor(feedbackColor)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(color: feedbackColor, radius: 5, x: 0, y: 3)
                            .transition(.scale)
                    }
                }
            }
            .padding()
        }
    }
    
    func checkAnswer(option: String) {
        let correctAnswer = questions[currentLevel - 1].answer
        if option == correctAnswer {
            feedbackMessage = "Correct! ✅"
            feedbackColor = .green
            showFeedback = true
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                if currentLevel < questions.count {
                    showFeedback = false
                    currentLevel += 1
                } else {
                    isCompleted = true
                    showFeedback = false
                }
            }
        } else {
            feedbackMessage = "Wrong answer! Try again. ❌"
            feedbackColor = .red
            showFeedback = true
        }
    }
}
