import SwiftUI

class NavigationManager: ObservableObject {
    @Published var currentView: String = "StartView"
    
    func resetToHomeView() {
        currentView = "HomeView"
    }
    
    func navigateToView(_ viewName: String) {
        currentView = viewName
    }
}
